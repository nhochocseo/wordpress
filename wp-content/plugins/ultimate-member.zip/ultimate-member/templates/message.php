<div class="um <?php echo $this->get_class( $mode ); ?> um-<?php echo esc_attr( $form_id ); ?>">

	<div class="um-postmessage">
		
		<?php echo $this->custom_message; ?>
		
	</div>
	
</div>