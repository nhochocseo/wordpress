<div class="um-admin-metabox">
	<p><?php echo UM()->shortcodes()->get_shortcode( get_the_ID() ); ?></p>
</div>